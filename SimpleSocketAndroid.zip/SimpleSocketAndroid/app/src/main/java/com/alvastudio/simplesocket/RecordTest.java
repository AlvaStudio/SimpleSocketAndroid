package com.alvastudio.simplesocket;

import android.media.AudioRecord;
import android.os.Environment;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import com.example.lame.Lame;

import java.io.File;
import java.io.FileOutputStream;

public class RecordTest extends AppCompatActivity {

    int minBuffer;
    int inSamplerate = 8000;

    String filePath = Environment.getExternalStorageDirectory() + File.separator + "testrecord.mp3";

    boolean isRecording = false;

    AudioRecord audioRecord;
    Lame androidLame;
    FileOutputStream outputStream;

    TextView statusText;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_record_test);

        Button start = findViewById(R.id.startRecording);
        Button stop = findViewById(R.id.stopRecording);

        statusText = findViewById(R.id.statusText);

        start.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (!isRecording) {
                    new Thread() {
                        @Override
                        public void run() {
                            isRecording = true;
                            //startRecording();
                        }
                    }.start();

                } else
                    Toast.makeText(RecordTest.this, "Already recording", Toast.LENGTH_SHORT).show();
            }
        });

        stop.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                isRecording = false;
            }
        });

    }
}
