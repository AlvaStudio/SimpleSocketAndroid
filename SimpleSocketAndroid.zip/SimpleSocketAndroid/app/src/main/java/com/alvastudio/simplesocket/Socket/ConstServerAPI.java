package com.alvastudio.simplesocket.Socket;

/**
 * Created by Apino on 14.08.16.
 */

public abstract class ConstServerAPI {

    public static final int PORT = 8283;
    public static final String ADDRESS = "10.0.2.2";//"95.79.36.14";//"192.168.1.110";//"91.219.57.45";//localtest "10.0.2.2";

    // Server MESSAGES
    public static final String SERVER_CONNECTED_OK = "0000";

}
